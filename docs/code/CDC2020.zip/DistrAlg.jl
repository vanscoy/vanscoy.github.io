################################################################################
# DISTRIBUTED ALGORITHM ANALYSIS -- version 4
#
# DATA TYPES:
#   convergence rate   rho = ρ
#   environment        env = (κ,σ)
#   algorithm          alg = (A,Bu,Bv,Cy,Cz,Dyu,Dyv,Dzu,Dzv,Fx,Fu)
#   solution to LMI    sol = dict containing X,Y,P,Q,R,G (or empty if infeasible)
#
# SYMBOLS:
#   :default - default parameter value
#
# CONSTANTS:
#   ALGNAMES - list of names for some known algorithms
#
# FUNCTIONS:
#
# algorithm definitions:
#   alg = getalg( algname, env; alpha=:default, mu=:default )
#   alpha,mu = defaultparams( algname, env )
#
# optimal algorithm:
#   alg,rho = getopt( env; tol=1e-5 )
#   sigma,zeta0 = sigopt( kappa, rho )
#
# main solver:
#   feas,[sol] = isfeasible( alg, env, rho; returnsol=false )
#
# parameter optimizations:
#   rhopt,              [sol] = optrho(   alg,     env;                     tol=1e-5, rhmin=0, rhmax=3.0, returnsol=false )
#   rhopt,              [sol] = optrho(   algname, env;                     tol=1e-5, rhmin=0, rhmax=3.0, returnsol=false )
#   rhopt,alphopt,      [sol] = optalpha( algname, env; mu=:default,        tol=1e-5, rhmin=0, rhmax=3.0, returnsol=false )
#   rhopt,alphopt,muopt,[sol] = optall(   algname, env; initcond=[1.0,1.0], tol=1e-5, rhmin=0, rhmax=3.0, returnsol=false )
#
# compute optimal convergence rate:
#   rhopts                 = compute_optrho(   algnames, envs; fname="",                 tol=1e-5, rhmin=0, rhmax=3.0, returnsol=false )
#   rhopts,alphopts        = compute_optalpha( algnames, envs; fname="",                 tol=1e-5, rhmin=0, rhmax=3.0, returnsol=false )
#   rhopts,alphopts,muopts = compute_optall(   algnames, envs; fname="", warmstart=true, tol=1e-5, rhmin=0, rhmax=3.0, returnsol=false )
#
# plot functions:
#   plot_sigmavary( algnames, rho, kappa,   sigvals; fname="" )
#   plot_kappavary( algnames, rho, kapvals, sig;     fname="" )
#
# search helper functions:
#   xopt = bsmin( f, a, b; tol=1e-5 )
#   xopt = bsmin( f, a, b; tol=1e-5 )
#   xopt,fopt = optim1D( f, a, b; tol=1e-5 )
#   xopt,fopt = optimND( f, x0 )
#
################################################################################

using Convex            # modeling of convex optimization problems
using MosekTools        # Mosek solver
# using SDPAFamily        # SDPA family of solvers (arbitrary precision)
using MathOptInterface  # modeling
using GenericSVD        # SVD (arbitrary precision)
using Suppressor        # suppress warnings
using Optim             # numerical optimization
using PyPlot            # plotting
using LinearAlgebra     # linear algebra
using JLD               # save/load data
using Formatting        # format output
using Polynomials       # polynomials (for computing SVL parameters)
using Printf            # print formatting

################################################################################
# ALGORITHMS
################################################################################

ALGNAMES = [ "EXTRA", "NIDS", "DIGing", "AugDGM", "ExDIFF", "uEXTRA", "uDIG", "SVL" ]

struct Algorithm{T}
    A::Matrix{T}
    Bu::Matrix{T}
    Bv::Matrix{T}
    Cy::Matrix{T}
    Cz::Matrix{T}
    Dyu::Matrix{T}
    Dyv::Matrix{T}
    Dzu::Matrix{T}
    Dzv::Matrix{T}
    Fx::Matrix{T}
    Fu::Matrix{T}
    
    # inner constructor that verifies that the algorithm has consistent dimensions
    function Algorithm{T}( A::Matrix{T}, Bu::Matrix{T}, Bv::Matrix{T}, Cy::Matrix{T}, Cz::Matrix{T}, Dyu::Matrix{T}, Dyv::Matrix{T}, Dzu::Matrix{T}, Dzv::Matrix{T}, Fx::Matrix{T}, Fu::Matrix{T} ) where {T}
        try
            [ A Bu Bv; Cy Dyu Dyv; Cz Dzu Dzv; Fx Fu zeros(size(Fx,1),size(Bv,2)) ]
        catch e
            error("Incompatible algorithm dimensions")
        end
        return new(A,Bu,Bv,Cy,Cz,Dyu,Dyv,Dzu,Dzv,Fx,Fu)
    end
end

"""
***Distributed Algorithm***
```julia
alg = Algorithm( A, Bu, Bv, Cy, Cz, Dyu, Dyv, Dzu, Dzv, Fx, Fu )
```
State-space representation of a distributed algorithm.
"""
function Algorithm( A::Array{T}, Bu::Array{T}, Bv::Array{T}, Cy::Array{T}, Cz::Array{T}, Dyu::Array{T}, Dyv::Array{T}, Dzu::Array{T}, Dzv::Array{T}, Fx::Array{T}, Fu::Array{T} ) where {T}
    
    # algorithm dimensions
    states         = size(A,1)
    computations   = size(Bu,2)
    communications = size(Bv,2)
    invariants     = size(Fx,1)
    
    # convert to matrices
    A   = reshape( A,   states,         states         )
    Bu  = reshape( Bu,  states,         computations   )
    Bv  = reshape( Bv,  states,         communications )
    Cy  = reshape( Cy,  computations,   states         )
    Cz  = reshape( Cz,  communications, states         )
    Dyu = reshape( Dyu, computations,   computations   )
    Dyv = reshape( Dyv, computations,   communications )
    Dzu = reshape( Dzu, communications, computations   )
    Dzv = reshape( Dzv, communications, communications )
    Fx  = reshape( Fx,  invariants,     states         )
    Fu  = reshape( Fu,  invariants,     computations   )
    
    # call the inner constructor
    return Algorithm{T}(A,Bu,Bv,Cy,Cz,Dyu,Dyv,Dzu,Dzv,Fx,Fu)
end

"""
```julia
n = num_state( alg )
```
Number of state variables `n` on each agent in the distributed algorithm `alg`.
"""
function num_states( alg::Algorithm )
    return size(alg.A,1)
end

"""
```julia
n = num_computations( alg )
```
Number of gradient computations `n` performed per iteration by each agent in the distributed algorithm `alg`.
"""
function num_computations( alg::Algorithm )
    return size(alg.Bu,2)
end

"""
```julia
n = num_communications( alg )
```
Number of variables `n` communicated with neighbors in the distributed algorithm `alg`.
"""
function num_communications( alg::Algorithm )
    return size(alg.Bv,2)
end

"""
```julia
A, Bu, Bv, Cy, Cz, Dyu, Dyv, Dzu, Dzv, Fx, Fu = ss( alg )
```
State-space representation of the distributed algorithm `alg`.
"""
function ss( alg::Algorithm )
    return alg.A, alg.Bu, alg.Bv, alg.Cy, alg.Cz, alg.Dyu, alg.Dyv, alg.Dzu, alg.Dzv, alg.Fx, alg.Fu
end

"""
```julia
T = numeric_type( alg )
```
Numeric type of the distributed algorithm `alg`.
"""
numeric_type( alg::Algorithm{T} ) where {T} = T

"""
```julia
alg = getalg( algname, kap, sig; alpha=:default, mu=:default )
```
Retrieve known distributed algorithms in feedback with the Laplacian matrix.
The stepsize and overrelaxation parameters (alpha,mu) can also be specified.
The default parameters from the corresponding paper can be specified using `:default`.
"""
function getalg( algname::String, kap::T, sig::T; alpha::Union{T,Symbol}=:default, mu::Union{T,Symbol}=:default ) where {T}
    
    # default parameters
    if alpha == :default
        alpha = defaultparams( algname, kap, sig )[1]
    end
    if mu == :default
        mu = defaultparams( algname, kap, sig )[2]
    end

    κ,σ,α,μ = kap,sig,alpha,mu
    
    begin
        if algname == "SVL"
            β,γ,δ = optparams( kap, sig )[2:4]
            Algorithm( T[1 β; 0 1], T[-α; 0], T[-γ; -1], T[1 0], T[1 0], T[0], T[-δ], T[0], T[0], T[0 1], T[0] )
        elseif algname == "EXTRA"
            Algorithm( T[2 -1 α; 1 0 0; 0 0 0], T[-α; 0; 1], T[-μ; 0; 0], T[1 0 0], T[1 -1/2 0], T[0], T[0], T[0], T[0], T[1 -1 α], T[0] )
        elseif algname == "NIDS"
            Algorithm( T[2 -1 α; 1 0 0; 0 0 0], T[-α;0;1], T[-μ; 0; 0], T[1 0 0], T[1 -1/2 α/2], T[0], T[0], T[-α/2], T[0], T[1 -1 α], T[0] )
        elseif algname == "ExDIFF"
            Algorithm( T[2 -1; 1 0], T[-α;-α], T[-μ; -μ/2], T[1 0], T[1 0], T[-μ/2], T[0], T[0], T[0], T[1 -1], T[0] )
        elseif algname == "DIGing"
            Algorithm( T[1 -α 0; 0 1 -1; 0 0 0], T[0;1;1], T[-μ 0; 0 -μ; 0 0], T[1 -α 0], T[1 0 0; 0 1 0], T[0], T[-μ 0], T[0;0], T[0 0; 0 0], T[0 1 -1], T[0] )
        elseif algname == "AugDGM"
            Algorithm( T[1 -α 0; 0 1 -1; 0 0 0], T[0;1;1], T[-μ α*μ; 0 -μ; 0 0], T[1 -α 0], T[1 0 0; 0 1 0], T[0], T[-μ α*μ], T[0;0], T[0 0; 0 0], T[0 1 -1], T[0] )
        elseif algname == "uDIG"
            Algorithm( T[1 -α; 0 1], T[-α;0], T[-μ 0; 0 -μ], T[1 0], T[1 0; -(1+1/κ)/2 1], T[0], T[0 0], T[0; 1], T[0 0; 0 0], T[0 1], T[0] )
        elseif algname == "uEXTRA"
            Algorithm( T[1 -α; 0 1], T[-α;0], T[-μ 0; 0 -μ], T[1 0], T[1 0; -1 1], T[0], T[0 0], T[0; 1], T[0 0; μ 0], T[0 1], T[0] )
        elseif algname == "SSDA"
            q = (√κ - √((1-σ)/(1+σ)))/(√κ + √((1-σ)/(1+σ)))
            Algorithm( T[0 1; -q 1+q], T[0;0], T[-α*μ;-α*(1+q)*μ], T[0 1], T[0 0], T[0], T[0], T[1], T[0], T[0 0], T[0] )
        elseif algname == "HAB"
            β = 0.1
            Algorithm( T[1+β -β -α 0; 1 0 0 0; 0 0 1 -1; 0 0 0 0], T[0;0;1;1], T[-μ 0; 0 0; 0 -μ; 0 0], T[1+β -β -α 0], T[1 0 0 0; 0 0 1 0], T[0], T[-μ 0], T[0;0], T[0 0; 0 0], T[0 0 1 -1], T[0] )
        else
            error("Unknown algorithm $algname")
        end
    end
end

"""
```julia
alpha, mu = defaultparams( algname, kap, sig )
```
Retrieve the default parameters `alpha` and `mu` for some known distributed algorithms from the corresponding paper.
"""
function defaultparams( algname::String, kap::T, sig::T ) where {T}
    
    κ,σ = kap,sig
    m = T(1/κ)
    L = T(1)
    
    begin
        if algname == "EXTRA"
            m*(1+σ)/(4*L^2), 1     # (not sure about this --- Remark 3, [Shi,Ling,Wu,Yin, SIAM J. OPTIM. 2015]
            #5/(4L), 1              # (does not work!) according to the new NIDS paper, which uses a bound from here: https://arxiv.org/abs/1711.06785
            #m*2/(4*L^2), 1         # this one works also,... (just replaced 1+σ by 2 in the first one)
        elseif algname == "NIDS"
            1/L, 1                 # (unsure how to pick this --- 2/L stated in the paper doesn't work), [Li,Shi,Yan, IEEE TRAN. SIG. PROC. 2019]
        elseif algname == "ExDIFF"
            1/L, 1                 # (unsure, need to read paper again)  [Yuan,Ying,Zhao,Sayed, IEEE TRAN. SIG. PROC. 2019, parts I and II]
        elseif algname == "DIGing"
            #m/L^2*((1-σ)/6)^2, 1   # Lemma 2 [check this and all subsequent -- CHECK THIS]  [Nedic,Olshevsky,Shi SIAM J. OPTIM. 2017]
            1-σ, 1               # just made these up...
        elseif algname == "AugDGM"
            1/L, 1                 # no default given in paper
        elseif algname == "uDIG"
            m/L^2*((1-σ)/6)^2, 1   # use same as DIGing
        elseif algname == "SSDA"
            1/L, 1                 # dunno...
        elseif algname == "HAB"
            1/L, 1
        elseif algname == "uEXTRA"
            m*(1-σ)/(4*L^2), 1     # use same as EXTRA
        elseif algname == "SVL"
            optparams( kap, sig )[1], 1   # optimal algorithm already has optimal α and μ
        else
            error("Unknown algorithm $algname")
        end
    end
end

"""
```julia
alg = convertLaplacianGossip( alg )
```
Converts (both ways) between an algorithm in feedback with the gossip matrix and an algorithm in feedback with the Laplacian matrix.
"""
function convertLaplacianGossip( alg::Algorithm )
    
    A,Bu,Bv,Cy,Cz,Dyu,Dyv,Dzu,Dzv,Fx,Fu = ss( alg )
    
    AA   = A   + Bv/(I-Dzv)*Cz
    BBu  = Bu  + Bv/(I-Dzv)*Dzu
    BBv  = -Bv/(I-Dzv)
    CCy  = Cy  + Dyv/(I-Dzv)*Cz
    CCz  = Cz  + Dzv/(I-Dzv)*Cz
    DDyu = Dyu + Dyv/(I-Dzv)*Dzu
    DDyv = -Dyv/(I-Dzv)
    DDzu = Dzu + Dzv/(I-Dzv)*Dzu
    DDzv = -Dzv/(I-Dzv)
    
    Algorithm(AA,BBu,BBv,CCy,CCz,DDyu,DDyv,DDzu,DDzv,Fx,Fu)
end

################################################################################
# OPTIMAL ALGORITHM
################################################################################

"""
```julia
alpha, beta, gamma, delta, rho = optparams( kap, sig; tol=1e-5 )
```
Optimal algorithm parameters `(alpha,beta,gamma,delta)` and the corresponding worst-case convergence rate `rho`.
`tol` is the tolerance for the bisection over sigma.
"""
function optparams( kap::T, sig::T; tol::T=T(1e-5) ) where {T}
    κ,σ = kap,sig

    if κ == 1
        ρ = σ
        β = 2*√κ/(κ+1)
    elseif κ == Inf || σ == 1
        ρ = 1
        β = 0
    elseif σ ≤ (√κ-1)/√(2*(κ+1.0))
        ρ = (κ-1)/(κ+1)
        β = 2*√κ/(κ+1)
    else
        ρ = bsmin( ρ -> (σ ≤ sigopt(κ,ρ)[1]), (κ-1)/(κ+1), T(1), tol=tol )
        β = sigopt( κ, ρ )[2]
    end
    α,γ,δ = κ*(1-ρ), 1+β, T(1)

    return α, β, γ, δ, ρ
end

"""
```julia
alg, rho = getopt( kap, sig; tol=1e-5 )
```
Optimal algorithm `alg` and the corresponding worst-case convergence rate `rho`. 'tol` is the tolerance for the bisection over sigma.
"""
function getopt( kap::T, sig::T; tol::T=T(1e-5) ) where {T}
    
    α,β,γ,δ,ρ = optparams( kap, sig, tol=tol )

    alg = Algorithm( T[1 β; 0 1], T[-α; 0], T[-γ; -1], T[1 0], T[1 0], T[0], T[-δ], T[0], T[0], T[0 1], T[0] )
    
    return alg, ρ
end

"""
```julia
sig, beta = sigopt( kap, rho )
```
Compute the maximum spectral gap `sig` and corresponding parameter `beta` given the condition ratio `kap` and convergence rate `rho`.
"""
function sigopt( kap, rho )

    κ = Float64(kap)
    ρ = Float64(rho)

    # edge cases
    if ρ == 0 || κ == 1
        return 0, 0
    elseif ρ == 1 || κ == Inf
        return 1, 1
    end

    # in this case, the cubic has a triple root at β = 1-ρ^2
    if κ == 1+2ρ
        return ρ/(2-ρ), 1-ρ^2
    end

    # the expressions are a little simpler using this definition
    η = 1+ρ-κ*(1-ρ)

    # coefficients of the cubic polynomial p0 + p1 β + p2 β^2 + p3 β^3
    p0 = η*(1-ρ^2)^2*(η-(3-η)*η*ρ+2ρ^2*(1-η)+2ρ^3)
    p1 = -(1-ρ^2)*(η^3*ρ+4ρ^5-2η*ρ^2*(2ρ^2+ρ-3)+η^2*(3-2ρ*(3+2ρ*(1-ρ))))
    p2 = 3η*(1-ρ)^2*(1+ρ)*(2ρ^2+η)
    p3 = (2ρ^2+η)*(2ρ^3-η)

    # roots of the cubic
    rts = roots(Polynomial([p0,p1,p2,p3]))

    # choose the correct root for β
    if κ < 1+2ρ
        ind = findall( (imag.(rts) .== 0) .& ((1-ρ)*(κ+1)/2 .< real.(rts) .< 1-ρ^2) )
    else
        ind = findall( (imag.(rts) .== 0) .& (1-ρ^2 .< real.(rts) .< (1-ρ)*(κ+1)/2) )
    end
    β = findmin( real.( rts[ind] ) )[1]

    # spectral gap
    σ = ρ*√( ( (β-1+ρ^2) * (2-η-2β) * ((2*ρ^2+η)*β-(1-ρ^2)*η) ) /
             ( (β-1+ρ) * (2ρ^2*β-(1-ρ^2)*η) * ((1+ρ)*(η-2η*ρ+2ρ^2)-(2ρ^2+η)*β) ) )

    return σ, β
end

################################################################################
# CONVERSIONS
################################################################################

"""
```julia
iter = rate_to_iterations( rho )
```
Converts the convergence rate `rho` to the number of iterations `iter` for the algorithm to converge to a given tolerance.
If `rho≥1`, the number of iterations is `Inf`.
"""
function rate_to_iterations( rho )
    iter = ( rho < 1 ? -1/log(rho) : Inf )
end

"""
```julia
rho = iterations_to_rate( iter )
```
Converts the number of iterations `iter` for the algorithm to converge to a given tolerance to the convergence rate `rho`.
If `iter=Inf`, then `rho=1`.
"""
function iterations_to_rate( iter )
    rho = exp(-1/iter)
end

"""
```julia
kap = rate_to_condition_ratio( rho )
```
Converts the convergence rate `rho` to the condition ratio `kap`.
"""
function rate_to_condition_ratio( rho )
    kap = (1+rho)/(1-rho)
end

"""
```julia
rho = condition_ratio_to_rate( kap )
```
Converts the condition ratio `kap` to the convergence rate `rho`.
"""
function condition_ratio_to_rate( kap )
    rho = (kap-1)/(kap+1)
end

"""
```julia
sigvals = getsigvals( λmin, λmax, pts )
```
Get a set of `pts` values for sigma evenly space on a log scale in the coordinates λ = (1+σ)/(1-σ) between `λmin` and `λmax`.
"""
function getsigvals( λmin::T, λmax::T, pts::Int ) where {T}
    
    lambda = exp.( range( log(λmin), log(λmax), length=pts ) )
    
    sigvals = (lambda .- 1) ./ (lambda .+ 1)
    
    return sigvals
end

"""
```julia
λvals = getλvals( λmin, λmax, pts )
```
Get a set of `pts` values for λ evenly space on a log scale between `λmin` and `λmax`.
"""
function getλvals( λmin::T, λmax::T, pts::Int ) where {T}
    λvals = exp.( range( log(λmin), log(λmax), length=pts ) )
end


"""
```julia
rho, alpha = DIGing_bound( kap, sig, B, n=2 )
```
Theoretical bound on the worst-case rate `rho` along with the corresponding stepsize `alpha` for DIGing.
The bound depends on the number of agents `n`.
"""
function DIGing_bound( kap::T, sig::T, B::Int, n::Int=2 ) where {T}

    m = T(1/kap)
    L = T(1)

    delta = sig^B

    # see Theorem 3.14
    J1 = 3*kap*B^2*( 1 + 4*sqrt( n*kap ) )

    alpha = 1.5*( sqrt( J1^2 + (1-delta^2)*J1 ) - delta*J1 )^2 / ( m*J1*( J1+1 )^2 )

    rho = ( 1 - alpha*m/1.5 )^(1/2B)
    
    return rho, alpha
end

"""
```julia
rho = lower_bound( kap, sig )
```
Lower bound on the worst-case rate `rho`.
"""
function lower_bound( kap::T, sig::T ) where {T}
    return max( sig, (kap-1)/(kap+1) )
end

################################################################################
# LINEAR MATRIX INEQUALITY
################################################################################

"""
```julia
feas, [sol] = isfeasible( alg, kap, sig, B, rho; solver=getsolver(T), returnsol=false )
```
Solve the LMI to determine whether or not an algorithm
converges for the given rate and environment parameters.
Optionally return the solution to the LMI.
"""
function isfeasible( alg::Algorithm{T}, kap::T, sig::T, B::Int, rho::T; solver=getsolver(T), returnsol::Bool=false ) where {T}
    
    κ,σ = kap,sig
    A,Bu,Bv,Cy,Cz,Dyu,Dyv,Dzu,Dzv,Fx,Fu = ss( convertLaplacianGossip( alg ) )

    # algorithm dimensions
    states         = num_states( alg )
    computations   = num_computations( alg )
    communications = num_communications( alg )

    # dimension of basis
    nx = states
    nu = B*computations
    nv = B*communications
    nw = (B-1)*communications
    d  = nx + nu + nv + nw

    # pre-allocate basis
    x = [ zeros(T,states,        d) for k in 1:B+1 ]
    y = [ zeros(T,computations,  d) for k in 1:B   ]
    z = [ zeros(T,communications,d) for k in 1:B   ]
    u = [ zeros(T,computations,  d) for k in 1:B   ]
    v = [ zeros(T,communications,d) for k in 1:B   ]
    w = [ zeros(T,communications,d) for k in 1:B+1 ]

    # construct basis: [ x[1]; u[1:B]; v[1:B]; w[3:B+1] ] = I
    x[1] = [ I zeros(T,states,nu+nv+nw) ]

    for k in 1:B
        u[k] = [ zeros(T,computations,nx+k-1) I zeros(T,computations,nu-k+nv+nw) ]
        v[k] = [ zeros(T,communications,nx+nu+(k-1)*communications) I zeros(T,communications,nv-k*communications+nw) ]
    end

    for k in 1:B
        x[k+1] =  A*x[k] +  Bu*u[k] +  Bv*v[k]
        y[k]   = Cy*x[k] + Dyu*u[k] + Dyv*v[k]
        z[k]   = Cz*x[k] + Dzu*u[k] + Dzv*v[k]
    end

    w[1] = z[1]
    w[2] = v[1]
    for k in 2:B
        w[k+1] = [ zeros(T,communications,nx+nu+nv+(k-2)*communications) I zeros(T,communications,nw-(k-1)*communications) ]
    end

    # matrices for quadratic forms
    M0 = T[-2 κ+1; κ+1 -2κ]
    M1 = T[σ^(2B) 0; 0 -1]
    M2 = T[1 0; 0 -1]

    # reduced basis in the consensus direction
    Id = Matrix{T}(I,B,B)
    
    Ψ = nullspace( [kron(Id,Fx) kron(Id,Fu) zeros(B*size(Fx,1),2*B*communications); zeros(2*B*communications,B*(states+1)) I] * vcat(x[1:B]...,u[1:B]...,[ v[k]-z[k] for k in 1:B ]...,[ w[k]-w[k+1] for k in 1:B ]...) )

    # Lyapunov function
    ξ0 = vcat(x[1],u[1:B-1]...,v[1:B-1]...)
    ξ1 = vcat(x[2],u[2:B]...,v[2:B]...)

    # dimension of Lyapunov function
    nξ = size(ξ0,1)

    # problem
    problem = Convex.satisfy( numeric_type=T )

    # variables
    P = Semidefinite(nξ)
    Q = Semidefinite(nξ)
    R = ( communications == 1 ? Variable(1, Positive()) : Semidefinite(communications) )
    S = [ Semidefinite(2*communications) for k in 1:B ]
    λ = Variable(B, Positive())

    # consensus LMI
    X0 = ξ1'*P*ξ1 - rho^2*(ξ0'*P*ξ0)

    for k in 1:B
        X0 += [y[k]; u[k]]'*kron(M0,λ[k])*[y[k]; u[k]]
    end

    X = Ψ'*X0*Ψ

    # disagreement LMI
    Y = ξ1'*Q*ξ1 - rho^2*(ξ0'*Q*ξ0)

    Y += [w[1]; w[B+1]]'*kron(M1,R)*[w[1]; w[B+1]]

    for k in 1:B
        Y += [y[k]; u[k]]'*kron(M0,λ[k])*[y[k]; u[k]]

        Y += [z[k]; w[k]; v[k]; w[k+1]]'*kron(M2,S[k])*[z[k]; w[k]; v[k]; w[k+1]]
    end

    # LMI constraints
    problem.constraints += [ -Matrix{T}(I,size(X))-X in :SDP ]
    problem.constraints += [ -Matrix{T}(I,size(Y))-Y in :SDP ]

    # break homogeneity
#     problem.constraints += [ tr(P) >= 1 ]
#     problem.constraints += [ tr(Q) >= 1 ]
    
    # solve
    solve!( problem, solver, verbose=false )
    
    # status
    feas = ( problem.status == MathOptInterface.OPTIMAL )

    # solution
    sol = Dict()
    if feas
        sol[:P] = P.value
        sol[:Q] = Q.value
        sol[:R] = R.value
        sol[:S] = [ S[k].value for k in 1:B ]
        sol[:λ] = λ.value
    end

    if returnsol
        return feas, sol
    else
        return feas
    end
end

"""
```julia
solver = getsolver( T, prec=100, tol=1e-12 )
```
Solver used to solve the LMI. Uses Mosek for data type `T = Float64` and SDPA for `T = BigFloat`.
"""
function getsolver( T::DataType, prec::Int=100, tol::Float64=1e-12 )
    
    if T == Float64
        
        solver = () -> Mosek.Optimizer(LOG=0,MAX_NUM_WARNINGS=0)
        
    elseif T == BigFloat
        
        # prec*(log(2)/log(10)) is approximate number of decimal digits of precision
        solver = () -> SDPAFamily.Optimizer(
            presolve = true,
            params = ( epsilonStar = tol,  # constraint tolerance
                       epsilonDash = tol,  # normalized duality gap tolerance
                       precision   = prec  # arithmetric precision
                     ))
    else
        error("Unknown solver for numeric type: $T")
    end
    
    return solver
end

################################################################################
# PARAMETER OPTIMIZATION FUNCTIONS
################################################################################

"""
```julia
rhopt, [sol] = optrho( alg, kap, sig, B; rhmin=1e-6, rhmax=2, rhtol=1e-6, returnsol=false )
```
Perform a bisection search to find the optimal worst-case convergence rate `rhopt`.
If the LMI is infeasible at `rhmax`, then `rhopt=NaN`.
"""
function optrho( alg::Algorithm{T}, kap::T, sig::T, B::Int;
        rhmin::T        = T(1e-6),
        rhmax::T        = T(10),
        rhtol::T        = T(1e-6),
        returnsol::Bool = false,
        ) where {T}
    
    rhopt = bsmin( rho -> isfeasible( alg, kap, sig, B, rho ), rhmin, rhmax, tol=rhtol )
    
    if returnsol
        feas, sol = isfeasible( alg, kap, sig, B, rhopt, returnsol=true )
        
        return rhopt, sol
    else
        return rhopt
    end
end

"""
```julia
rhopt, alphopt = optalpha( algname, kap, sig, B; alpha_min=5e-6, alpha_max=2, alpha_tol=1e-5, rhmax=10, rhmin=1e-6, rhmax=2, bisec_tol=1e-6 )
```
Find the stepsize `alphopt` that produces the optimal worst-case convergence rate `rhopt`.
"""
function optalpha( algname::String, kap::T, sig::T, B::Int;
        alphmin::T = T(5e-6),
        alphmax::T = max_stepsize( algname, kap, T(0), B ),
        alphtol::T = T(5e-6),
        kwargs...,
        ) where {T}
    
    # the parameters of SVL are already optimized
    if algname == "SVL"
        rhopt   = optrho( getalg(algname,kap,sig), kap, sig, B )
        alphopt = kap*(1-rhopt)
        
        return rhopt, alphopt
    end
    
    rho1 = optrho( getalg(algname,kap,sig,alpha=alphmin), kap, sig, B; kwargs... )
    rho2 = optrho( getalg(algname,kap,sig,alpha=alphmax), kap, sig, B; kwargs... )
    
    @debug "rho1=$rho1, rho2=$rho2"
    
    # the LMI must be feasible at alphmin and alphmax for the golden section search to work
    if isnan(rho1) || isnan(rho2)
        return T(1), NaN
    end
    
    rhmax = max( rho1, rho2 )
    
    fun = x -> optrho( getalg(algname,kap,sig,alpha=x), kap, sig, B; rhmax=rhmax, kwargs... )
    
    alphopt, rhopt = gss( fun, alphmin, alphmax, tol=alphtol )

    return rhopt, alphopt
end

"""
```julia
alphmax = max_stepsize( algname, kap, sig, B, rho=1; alphmin=0, alphmax=2, alphtol=1e-5 )
```
Finds the maximum stepsize `alphmax` such that the algorithm converges with rate `rho`.
If the LMI is infeasible at `alphmin`, then `alphmax=NaN`.
"""
function max_stepsize( algname::String, kap::T, sig::T, B::Int, rho::T=T(1); 
        alphmin::T = T(2e-5),
        alphmax::T = T(2),
        alphtol::T = T(1e-5),
        ) where {T}
    
    # the parameters of SVL are already optimized
    if algname == "SVL"
        rhopt   = optrho( getalg(algname,kap,sig), kap, sig, B )
        alphopt = kap*(1-rhopt)
        
        return alphopt
    end
    
    alphmax = bsmax( x -> isfeasible( getalg(algname,kap,sig,alpha=x), kap, sig, B, rho ), alphmin, alphmax, tol=alphtol )
end

"""
```julia
sigmax = max_spectral_gap( algname, kap, B, rho=1, alpha=:optimal; sigmin=0, sigmax=1, sigtol=1e-5 )
```
Finds the maximum spectral gap `sigmax` such that the algorithm converges with rate `rho`.
If the LMI is infeasible at `sigmin`, then `sigmax=NaN`.
"""
function max_spectral_gap( algname::String, kap::T, B::Int, rho::T=T(1), alpha::Union{T,Symbol}=:optimal;
        sigmin::T = T(0),
        sigmax::T = T(1),
        sigtol::T = T(1e-5),
        ) where {T}
    
    if alpha == :optimal
        sigmax = bsmax( sig -> optalpha( algname, kap, sig, B )[1] <= rho, sigmin, sigmax, tol=sigtol )
    else
        sigmax = bsmax( sig -> isfeasible( getalg(algname,kap,sig,alpha=alpha), kap, sig, B, rho ), sigmin, sigmax, tol=sigtol )
    end
    
    return sigmax + sigtol
end

################################################################################
# COMPUTE DATA USING STEPSIZE FROM DIGING PAPER
################################################################################

"""
```julia
compute_DIGing_bound( kap, B, pts, itermax, λinit, nvals; verbose=false )
```
Compute the bound from the DIGing paper.
"""
function compute_DIGing_bound( kap::T, B::Int, pts::Int, itermax::Int, λinit::Vector{T}, nvals::Vector{Int}; verbose::Bool=false ) where {T}
    
    for n in nvals
        
        # iterations to converge as a function of lambda
        f = function ( λ, λvals, iters, alphas )
            
            sig = condition_ratio_to_rate( λ )

            rho, alpha = DIGing_bound( kap, sig, B, n )

            iter = min( itermax, rate_to_iterations( rho ) )

            return iter, alpha
        end

        lambda, iter = adaptive_sample( f, λinit, max_samples=pts, xscale=log10, yscale=log10, verbose=verbose )

        sig = condition_ratio_to_rate.( lambda )
    
        rho = iterations_to_rate.( iter )

        # save data
        save( string( "../data/alphDIG/B", B, "/bound", n, ".jld" ),
            "kap",     kap,
            "B",       B,
            "sig",     sig,
            "lambda",  lambda,
            "rho",     rho,
            "iter",    iter )
    end
end

"""
```julia
compute_DIGing( kap, B, pts, itermax, λinit; n=2, warmstart=true, verbose=false )
```
Use the LMI to compute the bound for DIGing with the stepsize from the DIGing paper.
"""
function compute_DIGing( kap::T, B::Int, pts::Int, itermax::Int, λinit::Vector{T};
        n::Int          = 2,
        warmstart::Bool = true,
        verbose::Bool   = false,
        rhmax::T        = T(10),
        kwargs...,
        ) where {T}
    
    algname = "DIGing"
    
    # iterations to converge as a function of lambda
    f = function ( λ, λvals, iters, alphas )
        
        sig = condition_ratio_to_rate( λ )
        
        alpha = DIGing_bound( kap, sig, B, n )[2]
        
        alg = getalg( algname, kap, sig, alpha=alpha )
        
        # default bounds
        rho_min = lower_bound(kap,sig)
        rho_max = rhmax
        
        if warmstart && algname != "SVL"
            
            rhvals = iterations_to_rate.( iters )
            
            rho_min = maximum( vcat( rhvals[ λvals .< λ ], rho_min ) )
            rho_max = minimum( vcat( rhvals[ λvals .> λ ], rho_max ) )
        end
        
        rho = optrho( alg, kap, sig, B, rhmin=rho_min, rhmax=rho_max, kwargs... )
        
        iter = min( itermax, rate_to_iterations( rho ) )
        
        return iter, alpha
    end
    
    lambda, iter = adaptive_sample( f, λinit, max_samples=pts, xscale=log10, yscale=log10, verbose=verbose )
    
    sig = condition_ratio_to_rate.( lambda )
    
    rho = iterations_to_rate.( iter )
    
    # save data
    save( string( "../data/alphDIG/B",B,"/DIGing.jld" ),
        "algname", algname,
        "kap",     kap,
        "B",       B,
        "sig",     sig,
        "lambda",  lambda,
        "rho",     rho,
        "iter",    iter )
end

################################################################################
# COMPUTE DATA USING OPTIMAL STEPSIZE
################################################################################

"""
```julia
compute_alphopt( algname,  kap, B,     pts, itermax, λinit; verbose=false, warmstart=true )
compute_alphopt( algname,  kap, Bvals, pts, itermax, λinit; verbose=false, warmstart=true )
compute_alphopt( algnames, kap, B,     pts, itermax, λinit; verbose=false, warmstart=true )
compute_alphopt( algnames, kap, Bvals, pts, itermax, λinit; verbose=false, warmstart=true )
```
Compute the optimal stepsize and the corresponding worst-case converge rate.
"""
function compute_alphopt( algname::String, kap::T, B::Int, pts::Int, itermax::Int, λinit::Vector{T};
        alphmin::T      = T(5e-6),
        alphmax::T      = max_stepsize( algname, kap, T(0), B ),
        alphtol::T      = T(5e-6),
        verbose::Bool   = false,
        warmstart::Bool = true,
        ) where {T}
    
    time = @elapsed begin

        if isnan( alphmax )

            lambda = []
            iter   = []
            alpha  = []

        else

            # iterations to converge as a function of lambda
            f = function ( λ, λvals, iters, alphas )

                sig = condition_ratio_to_rate( λ )

                # warm-start
                if warmstart
                    alpha_min = maximum( vcat( alphas[ λvals .> λ ], alphmin ) )
                    alpha_max = minimum( vcat( alphas[ λvals .< λ ], alphmax ) )
                else
                    alpha_min = alphmin
                    alpha_max = alphmax
                end

                # compute optimal stepsize and corresponding rate
                rho, alpha = optalpha( algname, kap, sig, B, alphmin=alpha_min, alphmax=alpha_max )

                iter = min( itermax, rate_to_iterations( rho ) )

                return iter, alpha
            end

            lambda, iter, alpha = adaptive_sample( f, λinit, max_samples=pts, xscale=log10, yscale=log10, verbose=verbose )
        end

        sig = condition_ratio_to_rate.( lambda )

        rho = iterations_to_rate.( iter )
    end
    
    # display progress
    @printf( "%6s        κ = %.1f        B = %u        time = %4u sec\n", algname, kap, B, time )
    flush(stdout)
    
    # save data
    save( string("../data/alphopt/B",B,"/",algname,".jld" ),
        "algname", algname,
        "kap",     kap,
        "B",       B,
        "sig",     sig,
        "lambda",  lambda,
        "rho",     rho,
        "iter",    iter,
        "alpha",   alpha )
end

function compute_alphopt( algname::String, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λvals::Vector{T}; kwargs... ) where {T}
    
    for B in Bvals
        compute_alphopt( algname, kap, B, pts, itermax, λinit, kwargs... )
    end
end

function compute_alphopt( algnames::Vector{String}, kap::T, B::Int, pts::Int, itermax::Int, λvals::Vector{T}; kwargs... ) where {T}

    for algname in algnames
        compute_alphopt( algname, kap, B, pts, itermax, λinit, kwargs... )
    end
end

function compute_alphopt( algnames::Vector{String}, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λvals::Vector{T}; kwargs... ) where {T}

    for algname in algnames
        compute_alphopt( algname, kap, Bvals, pts, itermax, λinit, kwargs... )
    end
end

################################################################################
# PLOT HELPER FUNCTIONS
################################################################################

"""
```julia
y = monotone_increasing( x )
```
The vector `y` is the same as `x` except that it is monotone increasing.
"""
function monotone_increasing( x::Vector )
    
    for k = 2:length(x)
        x[k] = max(x[k],x[k-1])
    end
    
    return x
end

"""
```julia
cs = getcolor( algname )
```
Return the color string associated with the given algorithm.
"""
function getcolor( algname::String )
    if algname ==  "EXTRA"
        "C1"
    elseif algname == "NIDS"
        "C2"
    elseif algname == "DIGing"
        "C3"
    elseif algname == "AugDGM"
        "C4"
    elseif algname == "ExDIFF"
        "C5"
    elseif algname == "uEXTRA"
        "C6"
    elseif algname == "uDIG"
        "C7"
    elseif algname == "SVL"
        "C0"
    else
        error("Unknown algorithm $algname")
    end
end

"""
```julia
f, ax = setup_plot()
```
Setup the plot.
"""
function setup_plot()
    
    # plot settings
    plt.rc("text", usetex=true)
    plt.rc("font", size=8, family="sans-serif")

    # figure
    f, ax = plt.subplots(1, 1, figsize=(4.25,2.25))
    
    return f, ax
end

"""
```julia
save_plot_iterations( kap, pts, itermax, λmax, fname, ax )
```
Save the plot of the iterations to converge.
"""
function save_plot_iterations( kap::T, pts::Int, itermax::Int, λmax::T, fname::String, ax::PyPlot.PyCall.PyObject ) where {T}
    
    # lower bound
    sig    = getsigvals( T(1), λmax, pts )
    lambda = @. (1+sig)/(1-sig)
    iter   = [ rate_to_iterations(lower_bound(kap,s)) for s in sig ]
    ax.plot( lambda, iter, "k--", label="lower bound" )

    ax.set_xlabel( L"(1+\sigma)/(1-\sigma)" )
    ax.set_ylabel( "iterations to converge" )
    ax.grid()
    ax.legend( bbox_to_anchor=[1.05,1], loc=2, borderaxespad=0, framealpha=1 )
    ax.axis( [ 1, λmax, 3, itermax ] )
    ax.set_xscale("log")
    ax.set_yscale("log")

    tight_layout(pad=0.5)
    
    savefig( string( "../figures/iterations/", fname, ".pdf" ), pad_inches=0.0 )
end

"""
```julia
save_plot_stepsize( kap, pts, itermax, λmax, fname, ax )
```
Save the plot of the optimal stepsizes.
"""
function save_plot_stepsize( kap::T, pts::Int, itermax::Int, λmax::T, fname::String, ax::PyPlot.PyCall.PyObject ) where {T}

    ax.set_xlabel( L"(1+\sigma)/(1-\sigma)" )
    ax.set_ylabel( "stepsize \$\\alpha\$" )
    ax.grid()
    ax.legend( bbox_to_anchor=[1.05,1], loc=2, borderaxespad=0, framealpha=1 )
    ax.axis( [ 1, λmax, 0, 2 ] )
    ax.set_xscale("log")

    tight_layout(pad=0.5)
    
    savefig( string( "../figures/stepsize/", fname, ".pdf" ), pad_inches=0.0 )
end

################################################################################
# PLOT ITERATIONS TO CONVERGE USING THE OPTIMAL STEPSIZE
################################################################################

"""
```julia
plot_iterations( algname, B, ax; label="", transparency=1.0 )
```
Plot the iterations to converge from the stored data using the optimal stepsize.
"""
function plot_iterations( algname::String, B::Int, ax::PyPlot.PyCall.PyObject; label::String="", transparency::Float64=1.0 ) where {T}

    fname = string("../data/alphopt/B",B,"/",algname,".jld")

    @load fname lambda iter
    
    if algname != "SVL"
        iter = monotone_increasing(iter)
    end
    
    # AugDGM has numerical issues when the stepsize is very small
    if algname == "AugDGM" && B == 2
        iter[1:4] .= iter[5]
    end

    ax.plot( lambda, iter, color=getcolor(algname), linestyle="-", alpha=transparency, label=label )
end

"""
```julia
plot_iterations_all( algnames, kap, Bvals, pts, itermax, λmax )
```
Save the master plot of the iterations to converge for all algorithms and all values of B.
"""
function plot_iterations_all( algnames::Vector{String}, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λmax::T ) where {T}

    f, ax = setup_plot()
    
    transparency_vals = range( 0.2, 1, length=length(Bvals) )

    for algname in algnames
        
        for (B,transparency) in zip(reverse(Bvals),transparency_vals)

            label = ( B==1 ? algname : "" )
            
            plot_iterations( algname, B, ax, label=label, transparency=transparency )
        end
    end
    
    fname = "all_data"
    
    save_plot_iterations( kap, pts, itermax, λmax, fname, ax )
end

################################################################################
# PLOT ITERATIONS FOR FIXED B
################################################################################

"""
```julia
plot_iterations_for_fixed_B( algnames, kap, B,     pts, itermax, λmax )
plot_iterations_for_fixed_B( algnames, kap, Bvals, pts, itermax, λmax )
```
Plot the iterations to converge for each fixed value of B.
"""
function plot_iterations_for_fixed_B( algnames::Vector{String}, kap::T, B::Int, pts::Int, itermax::Int, λmax::T ) where {T}

    f, ax = setup_plot()

    for (i,algname) in enumerate(algnames)
        plot_iterations( algname, B, ax, label=algname )
    end
    
    ax.set_title( "\$\\kappa=$(Int(kap)),\\ B=$B,\\ \\alpha\$ optimizes LMI" )
    
    fname = string( "B", B )
    
    save_plot_iterations( kap, pts, itermax, λmax, fname, ax )
end

function plot_iterations_for_fixed_B( algnames::Vector{String}, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λmax::T ) where {T}
    for B in Bvals
        plot_iterations_for_fixed_B( algnames, kap, B, pts, itermax, λmax )
    end
end

################################################################################
# PLOT ITERATIONS FOR FIXED ALGORITHM
################################################################################

"""
```julia
plot_iterations_for_fixed_alg( kap, B,     pts, itermax, λmax )
plot_iterations_for_fixed_alg( kap, Bvals, pts, itermax, λmax )
```
Plot the iterations to converge for each fixed value of B.
"""
function plot_iterations_for_fixed_alg( algname::String, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λmax::T ) where {T}

    f, ax = setup_plot()

    transparency_vals = range( 0.2, 1, length=length(Bvals) )
    
    for (B,transparency) in zip(reverse(Bvals),transparency_vals)
        
        plot_iterations( algname, B, ax, label="\$B=$B\$", transparency=transparency )
    end
    
    ax.set_title( "\$\\kappa=$(Int(kap)),\\ \\alpha\$ optimizes LMI" )
    
    fname = algname
    
    save_plot_iterations( kap, pts, itermax, λmax, fname, ax )
end

function plot_iterations_for_fixed_alg( algnames::Vector{String}, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λmax::T ) where {T}
    for algname in algnames
        plot_iterations_for_fixed_alg( algname, kap, Bvals, pts, itermax, λmax )
    end
end

################################################################################
# PLOT THE OPTIMAL STEPSIZE
################################################################################

"""
```julia
plot_stepsize( algname, B, ax; label="", transparency=1.0 )
```
Plot the optimal stepsize from the stored data.
"""
function plot_stepsize( algname::String, B::Int, ax::PyPlot.PyCall.PyObject; label::String="", transparency::Float64=1.0 ) where {T}

    fname = string("../data/alphopt/B",B,"/",algname,".jld")

    @load fname lambda alpha

    ax.plot( lambda, alpha, color=getcolor(algname), linestyle="-", alpha=transparency, label=label )
end

"""
```julia
plot_stepsize_all( algnames, kap, Bvals, pts, itermax, λmax )
```
Save the master plot of the optimal stepsizes for all algorithms and all values of B.
"""
function plot_stepsize_all( algnames::Vector{String}, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λmax::T ) where {T}

    f, ax = setup_plot()
    
    transparency_vals = range( 0.2, 1, length=length(Bvals) )

    for algname in algnames
        
        for (B,transparency) in zip(reverse(Bvals),transparency_vals)

            label = ( B==1 ? algname : "" )
            
            plot_stepsize( algname, B, ax, label=label, transparency=transparency )
        end
    end
    
    fname = "all_data"
    
    save_plot_stepsize( kap, pts, itermax, λmax, fname, ax )
end

################################################################################
# PLOT OPTIMAL STEPSIZES FOR FIXED B
################################################################################

"""
```julia
plot_stepsize_for_fixed_B( algnames, kap, B,     pts, itermax, λmax )
plot_stepsize_for_fixed_B( algnames, kap, Bvals, pts, itermax, λmax )
```
Plot the iterations to converge for each fixed value of B.
"""
function plot_stepsize_for_fixed_B( algnames::Vector{String}, kap::T, B::Int, pts::Int, itermax::Int, λmax::T ) where {T}

    f, ax = setup_plot()

    for (i,algname) in enumerate(algnames)
        plot_stepsize( algname, B, ax, label=algname )
    end
    
    ax.set_title( "\$\\kappa=$(Int(kap)),\\ B=$B,\\ \\alpha\$ optimizes LMI" )
    
    fname = string( "B", B )
    
    save_plot_stepsize( kap, pts, itermax, λmax, fname, ax )
end

function plot_stepsize_for_fixed_B( algnames::Vector{String}, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λmax::T ) where {T}
    for B in Bvals
        plot_stepsize_for_fixed_B( algnames, kap, B, pts, itermax, λmax )
    end
end

################################################################################
# PLOT OPTIMAL STEPSIZES FOR FIXED ALGORITHM
################################################################################

"""
```julia
plot_stepsize_for_fixed_alg( kap, B,     pts, itermax, λmax )
plot_stepsize_for_fixed_alg( kap, Bvals, pts, itermax, λmax )
```
Plot the iterations to converge for each fixed value of B.
"""
function plot_stepsize_for_fixed_alg( algname::String, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λmax::T ) where {T}

    f, ax = setup_plot()

    transparency_vals = range( 0.2, 1, length=length(Bvals) )
    
    for (B,transparency) in zip(reverse(Bvals),transparency_vals)
        
        plot_stepsize( algname, B, ax, label="\$B=$B\$", transparency=transparency )
    end
    
    ax.set_title( "\$\\kappa=$(Int(kap)),\\ \\alpha\$ optimizes LMI" )
    
    fname = algname
    
    save_plot_stepsize( kap, pts, itermax, λmax, fname, ax )
end

function plot_stepsize_for_fixed_alg( algnames::Vector{String}, kap::T, Bvals::Vector{Int}, pts::Int, itermax::Int, λmax::T ) where {T}
    for algname in algnames
        plot_stepsize_for_fixed_alg( algname, kap, Bvals, pts, itermax, λmax )
    end
end

################################################################################
# PLOT DIGing
################################################################################

function plot_DIGing( kap::T, B::Int, pts::Int, itermax::Int, λmax::T, nvals::Vector{Int} ) where {T}

    f, ax = setup_plot()
    
    transparency_vals = range( 0.2, 1, length=length(nvals) )

    for (n,alpha) in zip(reverse(nvals),transparency_vals)
        
        fname = string("../data/alphDIG/B",B,"/bound",n,".jld")

        @load fname kap B sig lambda rho iter

        ax.plot( lambda, iter, color=getcolor("DIGing"), linestyle="--", alpha=alpha, label="\$n=$n\$" )
    end
    
    fname = string("../data/alphDIG/B",B,"/DIGing.jld")

    @load fname kap B sig lambda rho iter

    ax.plot( lambda, monotone_increasing(iter), color=getcolor("DIGing"), linestyle="-", alpha=1.0, label="all \$n\$" )
    
    ax.set_title( "\$\\kappa=$(Int(kap)),\\ B=$B,\\ \\alpha\$ optimizes DIGing bound" )
    
    fname = string( "alphDIG_B", B )
    
    save_plot_iterations( kap, pts, itermax, λmax, fname, ax )
end

function plot_DIGing( kap::T, B::Int, pts::Int, itermax::Int, λmax::T ) where {T}

    f, ax = setup_plot()

    plot_iterations( "DIGing", B, ax, label="all \$n\$" )
    
    ax.set_title( "\$\\kappa=$(Int(kap)),\\ B=$B,\\ \\alpha\$ optimizes LMI" )
    
    fname = string( "DIGing_B", B )
    
    save_plot_iterations( kap, pts, itermax, λmax, fname, ax )
end

################################################################################
# SEARCH HELPER FUNCTIONS
################################################################################

"""
**Bisection search to find minimum**
```julia
xopt = bsmin( f, a, b; tol=1e-5 )
```
Given a function `f` that returns true or false where `f(a) == false` and `f(b) == true`
and the function is monotone (only one cross-over point), returns the smallest input in
the interval `[a,b]` that still returns true within `tol`."""
function bsmin( f, a, b; tol=1e-5 )
    a,b = min(a,b),max(a,b)
    if f(a)
        return a
    end
    if !f(b)
        return NaN
    end
    while (b-a) > tol
        c = 0.5*(a + b)
        if f(c)
            b = c
        else
            a = c
        end
    end
    return b
end

"""
**Bisection search to find maximum**
```julia
xopt = bsmax( f, a, b; tol=1e-5 )
```
Given a function `f` that returns true or false where `f(a) == true` and `f(b) == false`
and the function is monotone (only one cross-over point), returns the largest input in
the interval `[a,b]` that still returns true within `tol`."""
function bsmax( f, a, b; tol=1e-5 )
    a,b = min(a,b),max(a,b)
    if f(b)
        return b
    end
    if !f(a)
        return NaN
    end
    while (b-a) > tol
        c = 0.5*(a + b)
        if f(c)
            a = c
        else
            b = c
        end
    end
    return a
end

"""
**Optimize 1-parameter family**
```julia
xopt,fopt = optim1D( f, a, b; tol=1e-5 )
```
Given a function `f` with a single local minimum in the interval `[a,b]`, `optim1D` returns a
minimizer xopt and minimum fopt such that `|xopt-xopt_true| < tol` (using Brent's method)
"""
function optim1D( f, a, b; tol=1e-5 )
    res = Optim.optimize(f,a,b,Brent(),abs_tol=tol)
    Optim.minimizer(res)..., Optim.minimum(res)
end

function optimND( f, x0 )
#     res = Optim.optimize(f,x0, NelderMead(initial_simplex = MatlabSimplexer()))
    res = Optim.optimize(f,x0, NelderMead())
    Optim.minimizer(res)..., Optim.minimum(res)
end

"""
```julia
xopt,fopt = optimSAMIN( f, lb, ub, x0 )
```
Uses simulated annealing with bounds to optimize a function of N variables subject to box constraints."""
function optimSAMIN( f, lb, ub, x0 )
    res = Optim.optimize(f,lb,ub,x0,SAMIN())
    Optim.minimizer(res)..., Optim.minimum(res)
end

"""
```julia
xopt,fopt = optimPS( f, lb, ub, x0 )
```
Uses particle swarm to optimize a function of N variables subject to constraints."""
function optimPS( f, lb, ub, x0 )
    res = Optim.optimize(f,x0,ParticleSwarm(; lower=lb, upper=ub))
    Optim.minimizer(res)..., Optim.minimum(res)
end

"""
```julia
xopt,fopt = gss( f, a, b; tol=1e-5 )
```
Given a strictly unimodal function `f` with a minimum in the interval `[a,b]`,
'gss' uses golden section search to return the unique optimum."""
function gss( f, a, b; tol=1e-5 )
    
    invphi  = (sqrt(5)-1)/2  # 1 / phi
    invphi2 = (3-sqrt(5))/2  # 1 / phi^2

    a,b = min(a,b), max(a,b)
    
    h = b-a
    if h <= tol
        return (a+b)/2, f((a+b)/2)
    end

    # number of steps to achieve tolerance
    n = Integer(ceil(log(tol/h)/log(invphi)))

    c = a + h*invphi2
    d = a + h*invphi
    yc = f(c)
    yd = f(d)

    for k in 1:(n-1)
        if yc < yd
            b = d
            d = c
            yd = yc
            h = h*invphi
            c = a + h*invphi2
            yc = f(c)
        else
            a = c
            c = d
            yc = yd
            h = h*invphi
            d = a + h*invphi
            yd = f(d)
        end
    end

    interval = ( yc < yd ? (a,d) : (c,b) )
    
    minimizer = 0.5*sum(interval)
    minimum   = f(minimizer)
    
    return minimizer, minimum
end

################################################################################
# ADAPTIVE SAMPLING
################################################################################

"""
***Adaptive Sampling***
```julia
xvals,fvals = adaptive_sample( f, xinit; max_samples=100, max_area=0, xscale=x->x, fscale=x->x, verbose=false )
```
Adaptively samples the function `f` including the points in the vector `xinit`
up to a maximum number of `max_samples` or until the maximum area between angles
at any two consecutive points is `max_area`."""
function adaptive_sample( f, xinit; max_samples=100, max_area=-1, max_angle=120, xscale=x->x, yscale=x->x, verbose=false )
    
    xvals = []
    yvals = []
    zvals = []
    
    # sample the initial points
    for x in xinit
        
        y, z = f( x, xvals, yvals, zvals )
        
        push!( xvals, x )
        push!( yvals, y )
        push!( zvals, z )
        
        # display progress
        if verbose
            display( ("sampled", x, y, z) )
        end
    end
    
    # sample more points until either the angles of all points have
    # a small enough area or the maximum number of samples is reached 
    for count = length(xinit)+1:max_samples
        
        angles = compute_angles( xscale.(xvals), yscale.(yvals) )
        
        areas = compute_areas( xscale.(xvals), angles )
        
        # sample a new point
        maxA,k = findmax( areas )
        
        if maxA > max_area
            
            # sample the interval with the largest area
            θ = rand()  # 0.5
            x = θ*xvals[k+1] + (1-θ)*xvals[k]
            
            y, z = f( x, xvals, yvals, zvals )
            
            push!( xvals, x )
            push!( yvals, y )
            push!( zvals, z )
            
            # sort the samples
            s = sortperm( xvals )
            
            xvals = xvals[s]
            yvals = yvals[s]
            zvals = zvals[s]
            
            # display progress
            if verbose
                display( ("sampled", x, y, z) )
            end
        else
            break
        end
        
        angles = compute_angles( xscale.(xvals), yscale.(yvals) )
        
        # remove any sample whose angle is too large
        while !isnothing( findfirst( angles .> max_angle ) )
            
            # index of sample with maximum angle
            k = findmax( angles )[2]
            
            # display progress
            if verbose
                display( ("removed", xvals[k], yvals[k], zvals[k], angles[k]) )
            end

            # remove the sample
            deleteat!( xvals, k )
            deleteat!( yvals, k )
            deleteat!( zvals, k )

            # recompute the angles
            angles = compute_angles( xscale.(xvals), yscale.(yvals) )
        end
    end
    
    return xvals, yvals, zvals
end

"""
```julia
angles = compute_angles( xvals, yvals )
```
Compute the angles between pairs of points in `xvals` and `yvals`.
"""
function compute_angles( xvals, yvals )
    
    # compute angles
    angles = zeros(length(xvals))
    
    for k = 2:length(xvals)-1
        a = [ yvals[k+1]-yvals[k]; xvals[k+1]-xvals[k] ]
        b = [ yvals[k-1]-yvals[k]; xvals[k-1]-xvals[k] ]
        z = dot(a,b)/(norm(a)*norm(b))
        
        angles[k] = ( z < -1 ? 0 : 180-180/π*acos(z) )
    end
    
    return angles
end

"""
```julia
areas = compute_areas( xvals, yvals )
```
Compute the areas of the trapezoids connecting pairs of points in `xvals` and `yvals`.
"""
function compute_areas( xvals, yvals )
    areas = [ abs( (xvals[k+1]-xvals[k]) * (yvals[k+1]+yvals[k]) / 2 ) for k in 1:length(xvals)-1 ]
end
;